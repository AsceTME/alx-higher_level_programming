#!/usr/bin/python3
"""
Module 0-rectangle
Contains class Rectangle
Empty class
"""


class Rectangle():
    """
    Defines empty class rectangle
    """
    pass
